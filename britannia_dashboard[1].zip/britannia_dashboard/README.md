# Britannia Industries — Executive Financial Intelligence Dashboard

Interactive Streamlit dashboard built on **five years of consolidated financials (FY2021-22 → FY2025-26, ₹ crore)** extracted from Britannia's annual reports.

## Run it
```bash
cd britannia_dashboard
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py               # opens http://localhost:8501
```
Optional: `python build_dataset.py` regenerates the cleaned dataset files in `data/`; `python -m src.data` prints the data-integrity checks.

## What's inside
| Path | Purpose |
|---|---|
| `app.py` | Streamlit UI — 7 requested sections + a Data & Verification page |
| `src/data.py` | **Verified dataset** (hand-extracted), derived items, 101 integrity checks, restatement log, sources |
| `src/ratios.py` | 45+ ratios with formulas, interpretation engine, transparent health-score model |
| `src/insights.py` | 26-test red-flag engine, per-chart management insights, executive commentary |
| `src/exports.py` | Excel (OpenPyXL, 10 formatted sheets) and CSV exports |
| `src/theme.py` | Navy / white / gold theme, KPI cards, Plotly styling |
| `data/` | Cleaned dataset (wide + tidy CSV), ratios, health scores, verification, restatements, sources, full Excel workbook |

## Dashboard sections
1. **Executive Overview** – 8 KPI cards (Revenue, EBITDA, EBITDA margin, PAT, PAT margin, Total assets, Debt, FCF) with deltas and sparklines; revenue→PAT waterfall; health-score gauge; five-year comparison table.
2. **Profitability** – revenue vs margin, profit ladder, margin trends, cost structure per ₹100 revenue, quality-of-earnings bridge, metric explorer.
3. **Balance Sheet** – asset mix, funding structure, debt profile/net debt, liquidity, treasury vs debt, operating working capital, metric explorer.
4. **Cash Flow** – CFO/CFI/CFF, FCF, cash-conversion quality, per-year and cumulative uses-of-cash waterfalls, capex vs depreciation, metric explorer.
5. **Ratios** – Profitability, Liquidity, Solvency, Efficiency, Cash-flow tabs: formula, 5-year values, trend, band and dynamic interpretation; ratio explorer; DuPont; working-capital cycle; pillar radar.
6. **Red Flags** – 26 rule-based tests, year × test heat map, filterable register, supporting evidence charts.
7. **Executive Insights** – health score, strengths, weaknesses, trend table, live watch-list, questions for management, methodology.
8. **Data & Verification** – statements, integrity checks, restatements, sources and notes.

**Top bar (v2, no side panel):** company header with a live snapshot strip (revenue, EBITDA margin, profit, net cash, FCF, health score, red flags) → section navigation pills → financial-year range, focus year, **🎨 Display** (colour palette, data labels, chart size) and **⬇ Export** (Excel / CSV, respecting the selected years).

**Interactivity (v2):** dark navy/gold theme; five switchable palettes; every key chart has its own view switch (Bars / Lines / Area / Stacked / 100% mix); each analysis page has a **Chart builder** where you choose any metrics, chart type and view (value, YoY %, indexed to 100, % of revenue); ratio explorer can overlay several ratios.

## Data basis (important)
* Source: the consolidated Balance Sheet, Statement of P&L and Cash Flow in the five annual reports supplied (PDF page numbers in `data/sources.csv`).
* Each year uses the **latest presentation** (the comparative column of the following year's report). Every difference from the originally published figure is in `data/restatement_log.csv` (FY22 balance-sheet reclassification; FY24/FY25 cash-flow reclassification).
* FY2020-21 appears only as an opening balance/base for FY22 growth and average-balance ratios.
* **EBITDA and EBIT are operating, analyst-derived** (revenue from operations less operating costs; other income excluded). A bridge to reported PBT is verified every year.
* Debt = current + non-current borrowings; lease liabilities shown separately. FY22 "dividends paid" includes bonus-debenture settlement (see notes). FY23 PBT/PAT include a ₹375.60 cr exceptional gain.
* Nothing is estimated. Items not extracted (segment data, contingent liabilities, market data) are out of scope.

## Customising
Scoring anchors: `SCORE_RULES` in `src/ratios.py`. Red-flag thresholds: the `_flag_*` functions in `src/insights.py`. Colours: `src/theme.py`.

## v3 additions
* **Plain-English charts:** every chart has a heading, a "How to read" line, labelled axes with units, best/weakest-point tags on key lines, and a "What this means" insight. Each page opens with a plain-English intro and ends with a glossary; KPI cards show a definition on hover.
* **Dark / Light mode:** toggle in the top bar (🌙 Dark mode). Charts, tables, cards and controls all follow it.
* **Typography:** DM Serif Display for headings, KPI numbers and chart titles; Inter for body text and data (fonts load from Google Fonts - needs internet; falls back to Georgia / Segoe UI).
* **Design:** card-based layout, soft shadows, pill navigation, theme-aware HTML tables (no dark/light mismatch).
