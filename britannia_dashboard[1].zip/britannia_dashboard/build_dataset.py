"""Regenerates the cleaned dataset files in ./data  (run:  python build_dataset.py)."""
from pathlib import Path

import pandas as pd

from src.data import FY, FY_LONG, LABELS, RESTATEMENT_LOG, SOURCES, STATEMENT_GROUPS, load_financials, long_format, run_verification
from src.exports import build_excel
from src.insights import build_ctx, build_flags
from src.ratios import RATIO_META, compute_ratios, health_scores

out = Path(__file__).parent / "data"
out.mkdir(exist_ok=True)
d = load_financials()
r = compute_ratios()

# 1. Wide statements: one row per line item, one column per year
rows = []
for stmt, keys in STATEMENT_GROUPS.items():
    for k in keys:
        rows.append([stmt, LABELS[k], k] + [round(float(d.loc[y, k]), 2) for y in FY])
pd.DataFrame(rows, columns=["Statement", "Line item (₹ crore)", "Key"] + [FY_LONG[y] for y in FY]).to_csv(
    out / "britannia_financials_5yr.csv", index=False, encoding="utf-8-sig")
# 2. Tidy / long format (BI-tool friendly)
long_format(d).to_csv(out / "britannia_financials_long.csv", index=False, encoding="utf-8-sig")
# 3. Ratios with formulas
rr = [[m["cat"], m["name"], k, m["unit"], m["formula"]] + [round(float(r.loc[y, k]), 4) for y in FY] for k, m in RATIO_META.items()]
pd.DataFrame(rr, columns=["Category", "Ratio", "Key", "Unit", "Formula"] + [FY_LONG[y] for y in FY]).to_csv(
    out / "britannia_ratios_5yr.csv", index=False, encoding="utf-8-sig")
health_scores(r).round(1).to_csv(out / "britannia_health_scores.csv", encoding="utf-8-sig")
# 4. Verification artefacts
run_verification().to_csv(out / "verification_checks.csv", index=False, encoding="utf-8-sig")
RESTATEMENT_LOG.to_csv(out / "restatement_log.csv", index=False, encoding="utf-8-sig")
SOURCES.to_csv(out / "sources.csv", index=False, encoding="utf-8-sig")
# 5. Full formatted workbook
c = build_ctx()
(out / "Britannia_Financial_Dataset_FY22_FY26.xlsx").write_bytes(build_excel(c.d, c.r, build_flags(c)["detail"], FY))
print("Dataset files written to", out)
